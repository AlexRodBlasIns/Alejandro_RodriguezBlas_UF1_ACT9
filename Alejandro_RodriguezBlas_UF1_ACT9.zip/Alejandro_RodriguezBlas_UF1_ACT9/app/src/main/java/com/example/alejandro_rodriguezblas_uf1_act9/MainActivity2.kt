package com.example.alejandro_rodriguezblas_uf1_act9

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class MainActivity2 : AppCompatActivity() {

    lateinit var botonActivity1: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        val myIntent2 = Intent(this, MainActivity::class.java)

        botonActivity1 = findViewById(R.id.button4)
        botonActivity1.setOnClickListener{
            startActivity(myIntent2)
        }

    }
}